# No Captcha ReCaptcha  #

### About ###
Use the new No Captcha ReCaptcha 

### Instructions ###
Enable, then visit settings/registration selecting NoCaptcha,
and providing Keys.

You may need to get new Keys. 
